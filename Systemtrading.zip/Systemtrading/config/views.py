from django.http import HttpResponse
from django.shortcuts import render
from burgers.models import *
import csv
import json
from django.forms.models import model_to_dict

def main(request):
    return HttpResponse("안녕하세요. 수급분석 프로그램입니다.")

def CSV_To_Models(request):
    # DB 초기화
    Burger.objects.all().delete()

    # CSV 경로
    path = r"volume.csv"

    # CSV 경로에 open 명령어 후 file 변수에 이식
    file = open(path)

    # csv를 읽어서 reader에 이식 심지어 Dict 형태로
    reader = csv.reader(file)

    # csv 첫번째 row 생략
    next(reader)

    burger_list = []
    burger_list_1 = []
    burger_list_2 = []



    for row in reader:

        initial_date = str(row[0])
        year = '20' + str(initial_date[0:2])
        month = str(initial_date[2:4])
        day = str(initial_date[4:6])

        final_date = year + '-' + month + '-' + day

        burger = Burger(
                date = final_date,
                current_price = float(row[1]) if row[1] else 0.0,
                individual = float(row[2]) if row[2] else 0.0,
                foreign = float(row[3]) if row[3] else 0.0,
                institutional = float(row[4]) if row[4] else 0.0,
                financial = float(row[5]) if row[5] else 0.0,
                insurance = float(row[6]) if row[6] else 0.0,
                investment_trust = float(row[7]) if row[7] else 0.0,
                other_financial = float(row[8]) if row[8] else 0.0,
                bank = float(row[9]) if row[9] else 0.0,
                pension_fund = float(row[10]) if row[10] else 0.0,
                private_equity_fund = float(row[11]) if row[11] else 0.0,
                nation = float(row[12]) if row[12] else 0.0,
                other_corporations = float(row[13]) if row[13] else 0.0,
                domestic_and_foreign = float(row[14]) if row[14] else 0.0,
                cumulative_individual = float(row[15]) if row[15] else 0.0,
                cumulative_foreign = float(row[16]) if row[16] else 0.0,
                cumulative_institutional = float(row[17]) if row[17] else 0.0,
                cumulative_financial = float(row[18]) if row[18] else 0.0,
                cumulative_insurance = float(row[19]) if row[19] else 0.0,
                cumulative_investment_trust = float(row[20]) if row[20] else 0.0,
                cumulative_other_financial = float(row[21]) if row[21] else 0.0,
                cumulative_bank = float(row[22]) if row[22] else 0.0,
                cumulative_pension_fund = float(row[23]) if row[23] else 0.0,
                cumulative_private_equity_fund = float(row[24]) if row[24] else 0.0,
                cumulative_nation = float(row[25]) if row[25] else 0.0,
                cumulative_other_corporations = float(row[26]) if row[26] else 0.0,
                cumulative_domestic_and_foreign = float(row[27]) if row[27] else 0.0,
                max_individual = float(row[28]) if row[28] else 0.0,
                max_foreign = float(row[29]) if row[29] else 0.0,
                max_institutional = float(row[30]) if row[30] else 0.0,
                max_financial = float(row[31]) if row[31] else 0.0,
                max_insurance = float(row[32]) if row[32] else 0.0,
                max_investment_trust = float(row[33]) if row[33] else 0.0,
                max_other_financial = float(row[34]) if row[34] else 0.0,
                max_bank = float(row[35]) if row[35] else 0.0,
                max_pension_fund = float(row[36]) if row[36] else 0.0,
                max_private_equity_fund = float(row[37]) if row[37] else 0.0,
                max_nation = float(row[38]) if row[38] else 0.0,
                max_other_corporations = float(row[39]) if row[39] else 0.0,
                max_domestic_and_foreign = float(row[40]) if row[40] else 0.0,
                min_individual = float(row[41]) if row[41] else 0.0,
                min_foreign = float(row[42]) if row[42] else 0.0,
                min_institutional = float(row[43]) if row[43] else 0.0,
                min_financial = float(row[44]) if row[44] else 0.0,
                min_insurance = float(row[45]) if row[45] else 0.0,
                min_investment_trust = float(row[46]) if row[46] else 0.0,
                min_other_financial = float(row[47]) if row[47] else 0.0,
                min_bank = float(row[48]) if row[48] else 0.0,
                min_pension_fund = float(row[49]) if row[49] else 0.0,
                min_private_equity_fund = float(row[50]) if row[50] else 0.0,
                min_nation = float(row[51]) if row[51] else 0.0,
                min_other_corporations = float(row[52]) if row[52] else 0.0,
                min_domestic_and_foreign = float(row[53]) if row[53] else 0.0,
                variance_ratio_individual = float(row[54]) if row[54] else 0.0,
                variance_ratio_foreign = float(row[55]) if row[55] else 0.0,
                variance_ratio_institutional = float(row[56]) if row[56] else 0.0,
                variance_ratio_financial = float(row[57]) if row[57] else 0.0,
                variance_ratio_insurance = float(row[58]) if row[58] else 0.0,
                variance_ratio_investment_trust = float(row[59]) if row[59] else 0.0,
                variance_ratio_other_financial = float(row[60]) if row[60] else 0.0,
                variance_ratio_bank = float(row[61]) if row[61] else 0.0,
                variance_ratio_pension_fund = float(row[62]) if row[62] else 0.0,
                variance_ratio_private_equity_fund = float(row[63]) if row[63] else 0.0,
                variance_ratio_nation = float(row[64]) if row[64] else 0.0,
                variance_ratio_other_corporations = float(row[65]) if row[65] else 0.0,
                variance_ratio_domestic_and_foreign = float(row[66]) if row[66] else 0.0,
            )

        burger_list.append(burger)


    Burger.objects.bulk_create(burger_list)

    # 데이터가 거꾸로 전송되서 리스트를 뒤집어서 전송함,
    json_data = json.dumps([model_to_dict(burger) for burger in burger_list[::-1]])





    Burger_1.objects.all().delete()

    path = r"volume_1.csv"

    # 파일을 안전하게 열기
    with open(path, 'r', encoding='utf-8') as file:
        reader = csv.reader(file)
        next(reader)  # 헤더 스킵


        # 모든 작업은 with문 안에서 진행되어야 함.
        for row in reader:


            burger_1 = Burger_1(
                date=str(row[0]),
                individual=round(float(row[1]) if row[1] else 0.0, 3),
                foreign=round(float(row[2]) if row[2] else 0.0, 3),
                institutional=round(float(row[3]) if row[3] else 0.0, 3),
                financial=round(float(row[4]) if row[4] else 0.0, 3),
                insurance=round(float(row[5]) if row[5] else 0.0, 3),
                investment_trust=round(float(row[6]) if row[6] else 0.0, 3),
                other_financial=round(float(row[7]) if row[7] else 0.0, 3),
                bank=round(float(row[8]) if row[8] else 0.0, 3),
                pension_fund=round(float(row[9]) if row[9] else 0.0, 3),
                private_equity_fund=round(float(row[10]) if row[10] else 0.0, 3),
                nation=round(float(row[11]) if row[11] else 0.0, 3),
                other_corporations=round(float(row[12]) if row[12] else 0.0, 3),
                domestic_and_foreign=round(float(row[13]) if row[13] else 0.0, 3),
            )

            burger_list_1.append(burger_1)

    Burger_1.objects.bulk_create(burger_list_1)





    # DB 초기화
    Burger_2.objects.all().delete()

    path = r"volume_2.csv"

    # 파일을 안전하게 열기
    with open(path, 'r', encoding='utf-8') as file:
        reader = csv.reader(file)
        next(reader)  # 헤더 스킵

        # 모든 작업은 with문 안에서 진행되어야 함.

        for row in reader:
            burger_2 = Burger_2(
                date=str(row[0]),
                individual=round(float(row[1]) if row[1] else 0.0, 3),
                foreign=round(float(row[2]) if row[2] else 0.0, 3),
                institutional=round(float(row[3]) if row[3] else 0.0, 3),
                financial=round(float(row[4]) if row[4] else 0.0, 3),
                insurance=round(float(row[5]) if row[5] else 0.0, 3),
                investment_trust=round(float(row[6]) if row[6] else 0.0, 3),
                other_financial=round(float(row[7]) if row[7] else 0.0, 3),
                bank=round(float(row[8]) if row[8] else 0.0, 3),
                pension_fund=round(float(row[9]) if row[9] else 0.0, 3),
                private_equity_fund=round(float(row[10]) if row[10] else 0.0, 3),
                nation=round(float(row[11]) if row[11] else 0.0, 3),
                other_corporations=round(float(row[12]) if row[12] else 0.0, 3),
                domestic_and_foreign=round(float(row[13]) if row[13] else 0.0, 3),
            )
            # 상관계수가 너무 지저분해서 round 함수로 소수점을 정리함.

            burger_list_2.append(burger_2)

        Burger_2.objects.bulk_create(burger_list_2)

    # 데이터가 거꾸로 전송되서 리스트를 뒤집어서 전송함,



    return render(request, 'burger_list.html', {"json_data": json_data, "burger_list_1": burger_list_1, "burger_list_2": burger_list_2})








