from django.contrib import admin
from burgers.models import *

@admin.register(Burger)
@admin.register(Burger_1)
@admin.register(Burger_2)
class BurgerAdmin(admin.ModelAdmin):
    pass

# Register your models here.
