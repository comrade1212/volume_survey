from django.db import models


class Burger(models.Model):
    date = models.CharField(max_length=100)
    current_price = models.FloatField(default=0)
    individual = models.FloatField(default=0)
    foreign = models.FloatField(default=0)
    institutional = models.FloatField(default=0)
    financial = models.FloatField(default=0)
    insurance = models.FloatField(default=0)
    investment_trust = models.FloatField(default=0)
    other_financial	= models.FloatField(default=0)
    bank = models.FloatField(default=0)
    pension_fund = models.FloatField(default=0)
    private_equity_fund = models.FloatField(default=0)
    nation = models.FloatField(default=0)
    other_corporations = models.FloatField(default=0)
    domestic_and_foreign = models.FloatField(default=0)
    cumulative_individual = models.FloatField(default=0)
    cumulative_foreign = models.FloatField(default=0)
    cumulative_institutional = models.FloatField(default=0)
    cumulative_financial = models.FloatField(default=0)
    cumulative_insurance = models.FloatField(default=0)
    cumulative_investment_trust = models.FloatField(default=0)
    cumulative_other_financial = models.FloatField(default=0)
    cumulative_bank = models.FloatField(default=0)
    cumulative_pension_fund = models.FloatField(default=0)
    cumulative_private_equity_fund = models.FloatField(default=0)
    cumulative_nation = models.FloatField(default=0)
    cumulative_other_corporations = models.FloatField(default=0)
    cumulative_domestic_and_foreign = models.FloatField(default=0)
    max_individual = models.FloatField(default=0)
    max_foreign = models.FloatField(default=0)
    max_institutional = models.FloatField(default=0)
    max_financial = models.FloatField(default=0)
    max_insurance = models.FloatField(default=0)
    max_investment_trust = models.FloatField(default=0)
    max_other_financial = models.FloatField(default=0)
    max_bank = models.FloatField(default=0)
    max_pension_fund = models.FloatField(default=0)
    max_private_equity_fund = models.FloatField(default=0)
    max_nation = models.FloatField(default=0)
    max_other_corporations = models.FloatField(default=0)
    max_domestic_and_foreign = models.FloatField(default=0)
    min_individual = models.FloatField(default=0)
    min_foreign = models.FloatField(default=0)
    min_institutional = models.FloatField(default=0)
    min_financial = models.FloatField(default=0)
    min_insurance = models.FloatField(default=0)
    min_investment_trust = models.FloatField(default=0)
    min_other_financial = models.FloatField(default=0)
    min_bank = models.FloatField(default=0)
    min_pension_fund = models.FloatField(default=0)
    min_private_equity_fund = models.FloatField(default=0)
    min_nation = models.FloatField(default=0)
    min_other_corporations = models.FloatField(default=0)
    min_domestic_and_foreign = models.FloatField(default=0)
    variance_ratio_individual = models.FloatField(default=0)
    variance_ratio_foreign = models.FloatField(default=0)
    variance_ratio_institutional = models.FloatField(default=0)
    variance_ratio_financial = models.FloatField(default=0)
    variance_ratio_insurance = models.FloatField(default=0)
    variance_ratio_investment_trust = models.FloatField(default=0)
    variance_ratio_other_financial = models.FloatField(default=0)
    variance_ratio_bank = models.FloatField(default=0)
    variance_ratio_pension_fund = models.FloatField(default=0)
    variance_ratio_private_equity_fund = models.FloatField(default=0)
    variance_ratio_nation = models.FloatField(default=0)
    variance_ratio_other_corporations = models.FloatField(default=0)
    variance_ratio_domestic_and_foreign = models.FloatField(default=0)

    def __str__(self):
        try :
            return f"{str(self.date)}, {int(self.current_price)}, {int(self.individual)}, {int(self.foreign)}, {int(self.institutional)}, {int(self.financial)}, {int(self.insurance)}, {int(self.investment_trust)}, {int(self.other_financial)}, {int(self.bank)}, {int(self.pension_fund)}, {int(self.private_equity_fund)}, {int(self.nation)}, {int(self.other_corporations)}, {int(self.domestic_and_foreign)}, {int(self.cumulative_individual)}, {int(self.cumulative_foreign)}, {int(self.cumulative_institutional)}, {int(self.cumulative_financial)}, {int(self.cumulative_insurance)}, {int(self.cumulative_investment_trust)}, {int(self.cumulative_other_financial)}, {int(self.cumulative_bank)}, {int(self.cumulative_pension_fund)}, {int(self.cumulative_private_equity_fund)}, {int(self.cumulative_nation)}, {int(self.cumulative_other_corporations)}, {int(self.cumulative_domestic_and_foreign)}, {int(self.max_individual)}, {int(self.max_foreign)}, {int(self.max_institutional)}, {int(self.max_financial)}, {int(self.max_insurance)}, {int(self.max_investment_trust)}, {int(self.max_other_financial)}, {int(self.max_bank)}, {int(self.max_pension_fund)}, {int(self.max_private_equity_fund)}, {int(self.max_nation)}, {int(self.max_other_corporations)}, {int(self.max_domestic_and_foreign)}, {int(self.min_individual)}, {int(self.min_foreign)}, {int(self.min_institutional)}, {int(self.min_financial)}, {int(self.min_insurance)}, {int(self.min_investment_trust)}, {int(self.min_other_financial)}, {int(self.min_bank)}, {int(self.min_pension_fund)}, {int(self.min_private_equity_fund)}, {int(self.min_nation)}, {int(self.min_other_corporations)}, {int(self.min_domestic_and_foreign)}, {int(self.variance_ratio_individual)}, {int(self.variance_ratio_foreign)}, {int(self.variance_ratio_institutional)}, {int(self.variance_ratio_financial)}, {int(self.variance_ratio_insurance)}, {int(self.variance_ratio_investment_trust)}, {int(self.variance_ratio_other_financial)}, {int(self.variance_ratio_bank)}, {int(self.variance_ratio_pension_fund)}, {int(self.variance_ratio_private_equity_fund)}, {int(self.variance_ratio_nation)}, {int(self.variance_ratio_other_corporations)}, {int(self.variance_ratio_domestic_and_foreign)}"

        except (OverflowError, ValueError):
        # OverflowError나 ValueError가 발생하면 기본값으로 처리
            return 0
        # Create your models here.






class Burger_1(models.Model):
    date = models.CharField(max_length=100)
    individual = models.FloatField(default=0)
    foreign = models.FloatField(default=0)
    institutional = models.FloatField(default=0)
    financial = models.FloatField(default=0)
    insurance = models.FloatField(default=0)
    investment_trust = models.FloatField(default=0)
    other_financial = models.FloatField(default=0)
    bank = models.FloatField(default=0)
    pension_fund = models.FloatField(default=0)
    private_equity_fund = models.FloatField(default=0)
    nation = models.FloatField(default=0)
    other_corporations = models.FloatField(default=0)
    domestic_and_foreign = models.FloatField(default=0)

    def __str__(self):
        try :
            return f"{str(self.date)}, {int(self.individual)}, {int(self.foreign)}, {int(self.institutional)}, {int(self.financial)}, {int(self.insurance)}, {int(self.investment_trust)}, {int(self.other_financial)}, {int(self.bank)}, {int(self.pension_fund)}, {int(self.private_equity_fund)}, {int(self.nation)}, {int(self.other_corporations)}, {int(self.domestic_and_foreign)}"

        except (OverflowError, ValueError):
            return 0







class Burger_2(models.Model):
    date = models.CharField(max_length=100)
    individual = models.FloatField(default=0)
    foreign = models.FloatField(default=0)
    institutional = models.FloatField(default=0)
    financial = models.FloatField(default=0)
    insurance = models.FloatField(default=0)
    investment_trust = models.FloatField(default=0)
    other_financial = models.FloatField(default=0)
    bank = models.FloatField(default=0)
    pension_fund = models.FloatField(default=0)
    private_equity_fund = models.FloatField(default=0)
    nation = models.FloatField(default=0)
    other_corporations = models.FloatField(default=0)
    domestic_and_foreign = models.FloatField(default=0)

    def __str__(self):
        try:
            return f"{str(self.date)}, {int(self.individual)}, {int(self.foreign)}, {int(self.institutional)}, {int(self.financial)}, {int(self.insurance)}, {int(self.investment_trust)}, {int(self.other_financial)}, {int(self.bank)}, {int(self.pension_fund)}, {int(self.private_equity_fund)}, {int(self.nation)}, {int(self.other_corporations)}, {int(self.domestic_and_foreign)}"

        except (OverflowError, ValueError):
            return 0