from PyQt5.QAxContainer import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
# API 사용에 필수적인 PyQt5 모듈
import pandas as pd
import time
import numpy as np

from datetime import datetime

from scipy import stats

current_date = datetime.now().strftime("%Y%m%d")


class Kiwoom(QAxWidget):
# QAxWidget을 상속한다.
    def __init__(self):
        super().__init__()
        # super는 QAxWidget을 의미하며, __init__()은 QAxWidget을 초기화해서 사용을 준비한다.
        self._make_kiwoom_instance()
        self._set_signal_slots()
        self._comm_connect()
        self.tr_event_loop = QEventLoop()

    def _make_kiwoom_instance(self):
        self.setControl("KHOPENAPI.KHOpenAPICtrl.1")
        # setControl 함수는 Kiwoom class를 만들 때 상속했던 QAxWidget class에 포함되어 있다.
        # 이 QAxWidget은 PyQt5.QAxContainer에 포함되어 있다. 그래서 정의없이 사용 가능하다.
        # KHOPENAPI.KHOpenAPICtrl.1란 키움증권에서 Open API를 설치하면 레지스트리에 모두 동일한 이름으로 저장된 API식별자이다.
    # kiwoom 클래스가 API를 사용할 수 있도록 등록하는 함수


    def _set_signal_slots(self):
    # API로 보내는 요청들을 받아 올 슬롯을 등록하는 함수
        self.OnEventConnect.connect(self._login_slot)
        # 로그인 시도 결과에 대한 응답을 _login_slot으로 받도록 설정

        self.OnReceiveTrData.connect(self._on_receive_tr_data)

    def _login_slot(self, err_code):
    # 로그인 시도 결과에 대한 응답을 얻는 함수
        if err_code == 0:
            print("connected")
        else:
            print("not connected")
        self.login_event_loop.exit()
        # 로그인 시도 결과에 대한 응답 대기 종료

    def _comm_connect(self):
    # 로그인 요청 신호를 보낸 이후 응답 대기를 설정하는 함수 : 로그인 함수
        self.dynamicCall("CommConnect()")

        self.login_event_loop = QEventLoop()
        self.login_event_loop.exec_()
        # 로그인 시도 결과에 대한 응답 대기 시작


    def insert_code(self):
        global code
        code = ""
        code = str(input("코드를 입력하세요."))
        return code



    def get_volume(self):
        # 거래량을 불러오는 함수
        self.dynamicCall("SetInputValue(QString, QString)","일자", current_date)
        self.dynamicCall("SetInputValue(QString, QString)", "종목코드", code)
        self.dynamicCall("SetInputValue(QString, QString)", "금액수량구분", "2")
        self.dynamicCall("SetInputValue(QString, QString)", "매매구분", "0")
        self.dynamicCall("SetInputValue(QString, QString)", "단위구분", "1")
        self.dynamicCall("CommRqData(QString, QString, int, QString", "opt10059_req", "opt10059", 0, "0001")

        self.tr_event_loop.exec_()

        ohlcv = self.tr_data

        count_num = 0

        while self.has_next_tr_data and count_num <= 42 :
            self.dynamicCall("SetInputValue(QString, QString)", "일자", current_date)
            self.dynamicCall("SetInputValue(QString, QString)", "종목코드", code)
            self.dynamicCall("SetInputValue(QString, QString)", "금액수량구분", "2")
            self.dynamicCall("SetInputValue(QString, QString)", "매매구분", "0")
            self.dynamicCall("SetInputValue(QString, QString)", "단위구분", "1")
            self.dynamicCall("CommRqData(QString, QString, int, QString", "opt10059_req", "opt10059", 2, "0001")

            count_num += 1

            self.tr_event_loop.exec_()

            for key, val in self.tr_data.items():
                ohlcv[key] += val


        df = pd.DataFrame(ohlcv, columns = ['current_price', 'individual','foreign','institutional','financial', 'insurance', 'investment_trust', 'other_financial', 'bank', 'pension_fund', 'private_equity_fund','nation', 'other_corporations', 'domestic_and_foreign'], index = ohlcv['date'])
        df.index.name = 'date'
        # 데이터프레임을 반환


        return df

    def make_cumulative_volume(self, volume_name, df):
        # 초기값 세팅
        cumulative_sum = 0
        cumulative = []
        cumulative_reverse = []

        # 거래량 역순 정렬
        for index, row in df.iloc[::-1].iterrows():
            cumulative_sum += row[volume_name]
            cumulative.append(cumulative_sum)

        # 거래량으로부터 받은 값 역순으로 정렬
        for i in range(len(cumulative) - 1, -1, -1):
            cumulative_reverse.append(cumulative[i])

        # 데이터 프레임 안에 삽입
        df['cumulative_'+volume_name] = cumulative_reverse

        return df


    def make_max_volume(self, volume_name, df):
        # 초기값 세팅
        max_volume = []
        max_volume_reverse = []

        # 거래량 역순 정렬
        max_ever = None
        for index, row in df.iloc[::-1].iterrows():
            if max_ever is None:
                max_ever = row['cumulative_' + volume_name]
            else:
                max_ever = max(max_ever, row['cumulative_' + volume_name])  # 최댓값 갱신
            max_volume.append(max_ever)

        # 거래량으로부터 받은 값 역순으로 정렬
        for i in range(len(max_volume) - 1, -1, -1):
            max_volume_reverse.append(max_volume[i])


        # 데이터 프레임 안에 새로운 열로 삽입
        df['max_' + volume_name] = max_volume_reverse

        return df




    def make_min_volume(self, volume_name, df):
        # 초기값 세팅
        min_volume = []
        min_volume_reverse = []

        # 거래량 역순 정렬
        min_ever = float(0)
        for index, row in df.iloc[::-1].iterrows():
            min_ever = min(min_ever, row['cumulative_' + volume_name])
            min_volume.append(min_ever)

        # 거래량으로부터 받은 값 역순으로 정렬
        for i in range(len(min_volume) - 1, -1, -1):
            min_volume_reverse.append(min_volume[i])

        # 데이터 프레임 안에 새로운 열로 삽입
        df['min_' + volume_name] = min_volume_reverse

        return df


    def make_variance_ratio(self, volume_name, df):

        a = []

        a = ((df.loc[:, 'cumulative_' + volume_name]) + abs((df.loc[:, 'min_' + volume_name]))) / (df.loc[:,'max_' + volume_name] + abs(df.loc[:, 'min_' + volume_name])) * 100
        df['variance_ratio_' + volume_name] = a

        df['variance_ratio_' + volume_name] = df['variance_ratio_' + volume_name].apply(lambda x: 100 if x > 100 else x)


        df.to_csv('volume.csv', encoding='utf-8-sig')

        return df

    def make_volume_table(self, df):
        trader_list = [
            'individual',
            'foreign',
            'institutional',
            'financial',
            'insurance',
            'investment_trust',
            'other_financial',
            'bank',
            'pension_fund',
            'private_equity_fund',
            'nation',
            'other_corporations',
            'domestic_and_foreign'
        ]

        ohlcv_1 = {'매집고점': [],
                   '누적합계' : [],
                   '최고저점': [],
                   '매집가능수량': [],
                   '분산비율': [],
                   'D-Day': [],
                   'D-1': [],
                   'D-2': [],
                   'D-3': [],
                   'D-4': [],
                   'D-5': [],
                   'D-6': [],
                   'D-7': [],
                   'D-8': [],
                   'D-9': [],
                   'D-10': [],
                   'D-11': [],
                   'D-12': [],
                   'D-13': [],
                   'D-14': [],
                   'D-15': [],
                   'D-16': [],
                   'D-17': [],
                   'D-18': [],
                   'D-19': [],
                   'D-20': [],
                   'D-21': [],
                   '1주': [],
                   '2주': [],
                   '3주': [],
                   '4주': [],
                   '1달': [],
                   '2달': [],
                   '3달': [],
                   '1분기': [],
                   '2분기': [],
                   '3분기': [],
                   '1년': [],
                   '2년': [],
                   '3년': [],
                   '4년': [],
                   '5년': [],
                   '6년': [],
                   '7년': [],
                   '8년': [],
                   '9년': [],
                   '10년': []

                   }


# df 생성

        df1 = pd.DataFrame(ohlcv_1,
                           columns=['individual',
                                    'foreign',
                                    'institutional',
                                    'financial',
                                    'insurance',
                                    'investment_trust',
                                    'other_financial',
                                    'bank',
                                    'pension_fund',
                                    'private_equity_fund',
                                    'nation',
                                    'other_corporations',
                                    'domestic_and_foreign'],

                           index=['매집고점',
                                  '누적합계',
                                  '최고저점',
                                  '매집가능수량',
                                  '분산비율',
                                    'D_Day',
                                    'D_1',
                                    'D_2',
                                    'D_3',
                                    'D_4',
                                    'D_5',
                                    'D_6',
                                    'D_7',
                                    'D_8',
                                    'D_9',
                                    'D_10',
                                    'D_11',
                                    'D_12',
                                    'D_13',
                                    'D_14',
                                    'D_15',
                                    'D_16',
                                    'D_17',
                                    'D_18',
                                    'D_19',
                                    'D_20',
                                    'D_21',
                                    '1주',
                                    '2주',
                                    '3주',
                                    '4주',
                                    '1달',
                                    '2달',
                                    '3달',
                                    '1분기',
                                    '2분기',
                                    '3분기',
                                    '1년',
                                    '2년',
                                    '3년',
                                    '4년',
                                    '5년',
                                    '6년',
                                    '7년',
                                    '8년',
                                    '9년',
                                    '10년',
                                  ])
        df1.index.name = 'date'



# 반복문 전에 list 초기화 해야 함.

        a = []
        b = []
        bbb = []
        c = []
        d = []
        e = []
        f = []
        g = []
        h = []
        h1 = []
        h2 = []
        h3 = []
        h4 = []
        h5 = []
        h6 = []
        h7 = []
        h8 = []
        h9 = []
        h10 = []
        h11 = []
        h12 = []
        h13 = []
        h14 = []
        h15 = []
        h16 = []
        h17 = []
        h18 = []
        ii = []
        j = []
        k = []
        l = []
        m = []
        n = []
        o = []
        p = []
        q = []
        r = []
        s = []
        t = []
        u = []
        v = []
        w = []
        x = []
        y = []
        z = []
        aa = []
        bb = []


        for i in trader_list:
            a.append((df['max_' + i].iloc[0]))
            bbb.append((df['cumulative_' + i].iloc[0]))
            b.append((df['min_' + i].iloc[0]))
            c.append((df['max_' + i].iloc[0])-(df['cumulative_' + i].iloc[0]))
            d.append((df['variance_ratio_' + i].iloc[0]))
            e.append((df[i].iloc[0]))
            f.append((df[i].iloc[1]))
            g.append((df[i].iloc[2]))
            h.append((df[i].iloc[3]))
            h1.append((df[i].iloc[4]))
            h2.append((df[i].iloc[5]))
            h3.append((df[i].iloc[6]))
            h4.append((df[i].iloc[7]))
            h5.append((df[i].iloc[8]))
            h6.append((df[i].iloc[9]))
            h7.append((df[i].iloc[10]))
            h8.append((df[i].iloc[11]))
            h9.append((df[i].iloc[12]))
            h10.append((df[i].iloc[13]))
            h11.append((df[i].iloc[14]))
            h12.append((df[i].iloc[15]))
            h13.append((df[i].iloc[16]))
            h14.append((df[i].iloc[17]))
            h15.append((df[i].iloc[18]))
            h16.append((df[i].iloc[19]))
            h17.append((df[i].iloc[20]))
            h18.append((df[i].iloc[21]))

            ii.append((df[i].iloc[4:8].sum()))
            j.append((df[i].iloc[9:13].sum()))
            k.append((df[i].iloc[14:18].sum()))
            l.append((df[i].iloc[19:23].sum()))

            m.append(df[i].iloc[1:24].sum())
            n.append(df[i].iloc[24:46].sum())
            o.append(df[i].iloc[47:69].sum())

            p.append(df[i].iloc[1:69].sum())
            q.append(df[i].iloc[70:138].sum())
            r.append(df[i].iloc[139:207].sum())

            s.append(df[i].iloc[1:275].sum())
            t.append(df[i].iloc[276:549].sum())
            u.append(df[i].iloc[560:823].sum())
            v.append(df[i].iloc[824:1097].sum())
            w.append(df[i].iloc[1098:1371].sum())
            x.append(df[i].iloc[1372:1645].sum())
            y.append(df[i].iloc[1920:2193].sum())
            z.append(df[i].iloc[2194:2467].sum())
            aa.append(df[i].iloc[2468:2741].sum())
            bb.append(df[i].iloc[2742:3015].sum())


        df1.loc['매집고점']= a
        df1.loc['누적합계'] = bbb
        df1.loc['최고저점']= b
        df1.loc['매집가능수량']= c
        df1.loc['분산비율']= d
        df1.loc['D_Day'] = e
        df1.loc['D_1'] = f
        df1.loc['D_2'] = g
        df1.loc['D_3'] = h
        df1.loc['D_4'] = h1
        df1.loc['D_5'] = h2
        df1.loc['D_6'] = h3
        df1.loc['D_7'] = h4
        df1.loc['D_8'] = h5
        df1.loc['D_9'] = h6
        df1.loc['D_10'] = h7
        df1.loc['D_11'] = h8
        df1.loc['D_12'] = h9
        df1.loc['D_13'] = h10
        df1.loc['D_14'] = h11
        df1.loc['D_15'] = h12
        df1.loc['D_16'] = h13
        df1.loc['D_17'] = h14
        df1.loc['D_18'] = h15
        df1.loc['D_19'] = h16
        df1.loc['D_20'] = h17
        df1.loc['D_21'] = h18
        df1.loc['1주'] = ii
        df1.loc['2주'] = j
        df1.loc['3주'] = k
        df1.loc['4주'] = m
        df1.loc['1달'] = l
        df1.loc['2달'] = n
        df1.loc['3달'] = o
        df1.loc['1분기'] = p
        df1.loc['2분기'] = q
        df1.loc['3분기'] = r
        df1.loc['1년'] = s
        df1.loc['2년'] = t
        df1.loc['3년'] = u
        df1.loc['4년'] = v
        df1.loc['5년'] = w
        df1.loc['6년'] = x
        df1.loc['7년'] = y
        df1.loc['8년'] = z
        df1.loc['9년'] = aa
        df1.loc['10년'] = bb


        df1.to_csv('volume_1.csv', encoding='utf-8-sig')

        return df1







    def make_spearmanr(self, df):

        ohlcv_2 = {
            'Day 1 ~ 21': [],
            'Day 24 ~ 46': [],
            'Day 47 ~ 69': [],
            'Day 1 ~ 69': [],
            'Day 70 ~ 138': [],
            'Day 139 ~ 207': [],
            'Day 1 ~ 275': [],
            'Day 276 ~ 549': [],
            'Day 560 ~ 823': [],
            'Day 824 ~ 1097': [],
            'Day 1098 ~ 1371': [],
            'Day 1372 ~ 1645': [],
            'Day 1920 ~ 2193': [],
            'Day 2194 ~ 2467': [],
            'Day 2468 ~ 2741': [],
            'Day 2742 ~ 3015': []
        }




        df_2 = pd.DataFrame(ohlcv_2,
                            columns=[
                                'individual',
                                'foreign',
                                'institutional',
                                'financial',
                                'insurance',
                                'investment_trust',
                                'other_financial',
                                'bank',
                                'pension_fund',
                                'private_equity_fund',
                                'nation',
                                'other_corporations',
                                'domestic_and_foreign'],

                            index=[
                                'Day 1 ~ 21',
                                'Day 22 ~ 46',
                                'Day 47 ~ 69',
                                'Day 1 ~ 69',
                                'Day 70 ~ 138',
                                'Day 139 ~ 207',

                                'Day 1 ~ 275',
                                'Day 276 ~ 549',
                                'Day 550 ~ 823',
                                'Day 824 ~ 1097',
                                'Day 1098 ~ 1371',
                                'Day 1372 ~ 1645',
                                'Day 1646 ~ 1919',
                                'Day 1920 ~ 2193',
                                'Day 2194 ~ 2467',
                                'Day 2468 ~ 2741',
                                'Day 2742 ~ 3015'])







        trader_list = [
            'individual',
            'foreign',
            'institutional',
            'financial',
            'insurance',
            'investment_trust',
            'other_financial',
            'bank',
            'pension_fund',
            'private_equity_fund',
            'nation',
            'other_corporations',
            'domestic_and_foreign'
        ]

        # 각 시간 범위에 대한 상관 계수 계산


        for time_range, start, end in [
            ('Day 1 ~ 21', 1, 21),
            ('Day 22 ~ 46', 22, 46),
            ('Day 47 ~ 69', 47, 69),

            ('Day 1 ~ 69', 1, 69),
            ('Day 70 ~ 138', 70, 138),
            ('Day 139 ~ 207', 139, 207),

            ('Day 1 ~ 275', 1, 275),
            ('Day 276 ~ 549', 276, 549),
            ('Day 550 ~ 823', 550, 823),
            ('Day 824 ~ 1097', 824, 1097),
            ('Day 1098 ~ 1371', 1098, 1371),
            ('Day 1372 ~ 1645', 1372, 1645),
            ('Day 1646 ~ 1919', 1646, 1919),
            ('Day 1920 ~ 2193', 1920, 2193),
            ('Day 2194 ~ 2467', 2194, 2467),
            ('Day 2468 ~ 2741', 2648, 2741),
            ('Day 2742 ~ 3015', 2742, 3015)
        ]:
        # 리스트에 있는 튜플 값을 각각 time_range, start, end에 할당해서 for 문을 돌린다.

            correlation_values = []
            for trader in trader_list:
                cumulative_data = df['cumulative_' + trader].iloc[start:end]
                current_price_data = df['current_price'].iloc[start:end]

                if np.std(cumulative_data) == 0 or np.std(current_price_data) == 0:
                    # 변동성이 없는 경우
                    correlation_values.append(0.0)
                else:
                    result = stats.spearmanr(cumulative_data, current_price_data)
                    correlation = result.correlation
                    p_value = result.pvalue

                    if p_value >= 0.05 or np.isnan(correlation):
                        correlation_values.append(0.0)
                    else:
                        correlation_values.append(round(correlation, 4))

            # 계산된 상관 계수를 df_2에 저장
            if len(correlation_values) == len(df_2.columns):
                df_2.loc[time_range] = correlation_values
            else:
                print(f"Error: Array size mismatch for {time_range}.")

        # 결과를 CSV 파일로 저장
        df_2.to_csv('volume_2.csv', encoding='utf-8-sig')






    def _on_receive_tr_data(self, screen_no, rqname, trcode, record_name, next, unused1, unused2, unused3, unused4):
        print("[Kiwoom] _on_receive_tr_data is Called {} / {} / {} / {}".format(screen_no, rqname, trcode, next))
        tr_data_cnt = self.dynamicCall("GetRepeatCnt(QString, QString)", trcode, rqname)
        print(tr_data_cnt)

        if next == '2':
            self.has_next_tr_data = True

        else:
            self.has_next_tr_data = False


        if rqname == "opt10059_req":
            ohlcv = {'date':[],
                     'current_price':[],
                     'individual':[],
                     'foreign':[],
                     'institutional':[],
                     'financial':[],
                     'insurance':[],
                     'investment_trust':[],
                     'other_financial':[],
                     'bank':[],
                     'pension_fund':[],
                     'private_equity_fund':[],
                     'nation':[],
                     'other_corporations':[],
                     'domestic_and_foreign':[]
                     }


            for i in range(tr_data_cnt):
                date = self.dynamicCall("GetCommData(QString, QString, QString, QString", trcode, rqname, i, "일자")
                current_price = self.dynamicCall("GetCommData(QString, QString, QString, QString", trcode, rqname, i,"현재가")
                individual = self.dynamicCall("GetCommData(QString, QString, QString, QString", trcode, rqname, i, "개인투자자")
                foreign = self.dynamicCall("GetCommData(QString, QString, QString, QString", trcode, rqname, i, "외국인투자자")
                institutional = self.dynamicCall("GetCommData(QString, QString, QString, QString", trcode, rqname, i, "기관계")
                financial = self.dynamicCall("GetCommData(QString, QString, QString, QString", trcode, rqname, i, "금융투자")
                insurance = self.dynamicCall("GetCommData(QString, QString, QString, QString", trcode, rqname, i, "보험")
                investment_trust = self.dynamicCall("GetCommData(QString, QString, QString, QString", trcode, rqname, i, "투신")
                other_financial = self.dynamicCall("GetCommData(QString, QString, QString, QString", trcode, rqname, i, "기타금융")
                bank = self.dynamicCall("GetCommData(QString, QString, QString, QString", trcode, rqname, i, "은행")
                pension_fund = self.dynamicCall("GetCommData(QString, QString, QString, QString", trcode, rqname, i, "연기금등")
                private_equity_fund = self.dynamicCall("GetCommData(QString, QString, QString, QString", trcode, rqname, i, "사모펀드")
                nation = self.dynamicCall("GetCommData(QString, QString, QString, QString", trcode, rqname, i, "국가")
                other_corporations = self.dynamicCall("GetCommData(QString, QString, QString, QString", trcode, rqname, i, "기타법인")
                domestic_and_foreign = self.dynamicCall("GetCommData(QString, QString, QString, QString", trcode, rqname, i, "내외국인")

                ohlcv['date'].append(date.strip()[2:])
                ohlcv['current_price'].append(abs(int(current_price)))
                ohlcv['individual'].append(int(individual))
                ohlcv['foreign'].append(int(foreign))
                ohlcv['institutional'].append(int(institutional))
                ohlcv['financial'].append(int(financial))
                ohlcv['insurance'].append(int(insurance))
                ohlcv['investment_trust'].append(int(investment_trust))
                ohlcv['other_financial'].append(int(other_financial))
                ohlcv['bank'].append(int(bank))
                ohlcv['pension_fund'].append(int(pension_fund))
                ohlcv['private_equity_fund'].append(int(private_equity_fund))
                ohlcv['nation'].append(int(nation))
                ohlcv['other_corporations'].append(int(other_corporations))
                ohlcv['domestic_and_foreign'].append(int(domestic_and_foreign))



            self.tr_data = ohlcv

        self.tr_event_loop.exit()
        time.sleep(0.2)