from api.Kiwoom import * # Kiwoom이 api라는 패키지 밑에 위치하기 때문에 이리 써야 함.
import sys



app = QApplication(sys.argv)
# PyQt5을 통해 API를 제어하는 코드. 그러려니 하자.

kiwoom = Kiwoom()

code = kiwoom.insert_code()

df = kiwoom.get_volume()

trader_list = [

                'individual',
                'foreign',
                'institutional',
                'financial',
                'insurance',
                'investment_trust',
                'other_financial',
                'bank',
                'pension_fund',
                'private_equity_fund',
                'nation',
                'other_corporations',
                'domestic_and_foreign'
              ]

for volume_name in trader_list:
    cumulative_volume = kiwoom.make_cumulative_volume(volume_name, df)
for volume_name in trader_list:
    max_volume = kiwoom.make_max_volume(volume_name, df)
for volume_name in trader_list:
    min_volume = kiwoom.make_min_volume(volume_name, df)
for volume_name in trader_list:
    make_variance_ratio = kiwoom.make_variance_ratio(volume_name, df)
volume_table = kiwoom.make_volume_table(df)

make_spearmanr = kiwoom.make_spearmanr(df)

print("main이는 할 일을 다 끝냈어요")


# app.exec_()
# # PyQt5을 통해 API를 제어하는 코드. 무한루프를 돌림