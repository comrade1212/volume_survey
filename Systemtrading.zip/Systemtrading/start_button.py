# -*- coding: utf-8 -*-
import subprocess
import webbrowser
import time

subprocess.call(['first.bat'], shell=True)
time.sleep(2.0)
url = 'http://127.0.0.1:8000/CTM/'  # 이동하고자 하는 URL
chrome_path = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'  # Chrome 실행 파일 경로

webbrowser.register('chrome', None, webbrowser.BackgroundBrowser(chrome_path))
webbrowser.get('chrome').open(url)