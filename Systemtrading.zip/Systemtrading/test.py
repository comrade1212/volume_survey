def mysum(a, b) :
    result = a + b
    print(result)

def mysum(a, b) :
    result = a + b
    return result